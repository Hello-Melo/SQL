drop table tb_sp2;

create table tb_sp1(
col varchar(5)
);

create table tb_sp2(
col varchar(10)
);

select * from tb_sp1;
select * from tb_sp2;